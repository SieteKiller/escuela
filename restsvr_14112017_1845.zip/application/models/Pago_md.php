<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Pago_md extends CI_Model {

	public function __construct()
	{
		parent::__construct();		
	}
	public function t_materias($id_t_materia="",$dbg=0)
	{
		
		$qa="";
		if($id_t_materia!="")
		{
			$qa=" WHERE id_t_materias in ($id_t_materia) ";
		}
		$sql = "select id_t_materias,nombre,activo from t_materias $qa order by nombre asc";
		if($dbg==1)
		{
			echo "<pre> sql { ".$sql." } </pre>";
		}

		$qry = $this->db->query($sql);
		#echo "<br> qry $query<br>";
		#var_dump($qry);
		return $qry->result();
	}
	public function t_usuarios($id_t_usuarios="",$dbg=0)
	{
		
		$qa="";
		if($id_t_usuarios!="")
		{
			$qa=" WHERE id_t_usuarios in ($id_t_usuarios) ";
		}
		$sql = "select id_t_usuarios,nombre,ap_paterno,ap_materno,activo from t_alumnos $qa order by nombre,ap_paterno,ap_materno asc";
		if($dbg==1)
		{
			echo "<pre> sql { ".$sql." } </pre>";
		}

		$qry = $this->db->query($sql);
		#echo "<br> qry $query<br>";
		#var_dump($qry);
		return $qry->result();
	}
	public function agrega_calificacion($datos){
		$maximo=0;
		$qry = $this->db->query("SELECT max(id_t_calificaciones)+1 as maximo from t_calificaciones");
		if ($qry->num_rows() > 0)
		{
			foreach ($qry->result() as $row)
			{
			   $maximo=$row->maximo;
			}
		}
		else
		{
			$maximo=1;
		}
			
		$id_t_materias=$datos["id_t_materias"];
		$id_t_usuarios=$datos["id_t_usuarios"];
		$fecha_registro=$datos["fecha_registro"];
		$calificacion=$datos["calificacion"];		

		$sql = "INSERT INTO t_calificaciones (id_t_calificaciones,id_t_materias,id_t_usuarios,fecha_registro,calificacion)
				VALUES ('".$maximo."','".$id_t_materias."','".$id_t_usuarios."','".$fecha_registro."','".$calificacion."')";
		

		if($this->db->query($sql))
		{
			$msg=1;
			return $msg;
		}
		else
		{
			$msg=0;
			return $msg;
		}

		//$this->db->insert('t_calificaciones', $datos);
	}

	public function v_calificaciones($id_t_usuarios="",$dbg=0)
	{
		
		$qa="";
		if($id_t_usuarios!="")
		{
			$qa=" WHERE id_t_usuarios in ($id_t_usuarios) ";
		}
		$sql = "select * from v_calificaciones $qa ";
		if($dbg==1)
		{
			echo "<pre> sql { ".$sql." } </pre>";
		}

		$qry = $this->db->query($sql);
		#echo "<br> qry $query<br>";
		#var_dump($qry);
		return $qry->result();
	}
	public function elimina_calificacion($id_t_calificaciones="",$dbg=0)
	{
		
		$qa="";
		if($id_t_calificaciones!="")
		{
			$qa=" WHERE id_t_calificaciones in ($id_t_calificaciones) ";
		}
		$sql = "delete from t_calificaciones $qa ";
		if($dbg==1)
		{
			echo "<pre> sql { ".$sql." } </pre>";
		}

		$qry = $this->db->query($sql);
		#echo "<br> qry $query<br>";
		#var_dump($qry);
		if($qry)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
public function actualiza_calificacion($datos){
		$maximo=0;
		
		$id_t_calificaciones=$datos["id_t_calificaciones"];	
		$id_t_materias=$datos["id_t_materias"];
		$id_t_usuarios=$datos["id_t_usuarios"];
		$fecha_registro=$datos["fecha_registro"];
		$calificacion=$datos["calificacion"];		

		$qry = $this->db->query("SELECT id_t_calificaciones from t_calificaciones where id_t_calificaciones='$id_t_calificaciones'");
		if ($qry->num_rows() > 0)
		{
			$maximo=1;
		}
		
		if($maximo!=0)
		{
		$sql = "UPDATE t_calificaciones SET 
				id_t_materias='".$id_t_materias."',
				id_t_usuarios='".$id_t_usuarios."',
				fecha_registro='".$fecha_registro."',
				calificacion='".$calificacion."'
				WHERE id_t_calificaciones='".$id_t_calificaciones."';";			
			if($this->db->query($sql))
			{
				$msg=1;
				return $msg;
			}
			else
			{
				$msg=0;
				return $msg;
			}

		}
		else
		{
			$msg=0;
			return $msg;
		}
		
		//$this->db->insert('t_calificaciones', $datos);
	}

}

/* End of file Pago_md.php */
/* Location: ./application/models/Pago_md.php */