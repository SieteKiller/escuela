<?php

defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . 'libraries/REST_Controller.php';

/**
 * This is an example of a few basic user interaction methods you could use
 * all done with a hardcoded array
 *
 * @package         CodeIgniter
 * @subpackage      Rest Server
 * @category        Controller
 * @author          Phil Sturgeon, Chris Kacerguis
 * @license         MIT
 * @link            https://github.com/chriskacerguis/codeigniter-restserver
 */
class Pago extends REST_Controller {

    function __construct()
    {
        // Construct the parent class
        parent::__construct();


        // Configure limits on our controller methods
        // Ensure you have created the 'limits' table and enabled 'limits' within application/config/rest.php
        $this->methods['users_get']['limit'] = 500; // 500 requests per hour per user/key
        $this->methods['users_post']['limit'] = 100; // 100 requests per hour per user/key
        $this->methods['users_put']['limit'] = 100; // 100 requests per hour per user/key
        $this->methods['users_delete']['limit'] = 50; // 50 requests per hour per user/key
    }

    public function calificaciones_get()
    {
        // Users from a data store e.g. database
        $this->load->model('pago_md');
        $id = $this->get('id');

        //var_dump($_GET);exit;

            $calificaciones = $this->pago_md->v_calificaciones($id,0);
            #var_dump($calificaciones);
            if ($calificaciones)
            {
                $c_calificaciones=count($calificaciones);
                if($c_calificaciones>0)
                {
                    echo "[";
                    $users=array();$cuenta=0;$total=0;$promedio=0;
                    foreach ($calificaciones as $c)
                    {       $id_t_usuarios=$c->id_t_usuarios;
                            $nombre=$c->nombre;
                            $ap_paterno=$c->ap_paterno;
                            $ap_materno=$c->ap_materno;
                            $materia=$c->materia;
                            $calificacion=$c->calificacion;
                            $fecha_registro=$c->fecha_registro;
                            echo "{id_t_usuarios: $id_t_usuarios,\"nombre\": \"$nombre\",\"apellido\": \"$ap_paterno\",\"materia\": \"$materia\",\"calificacion\": $calificacion,\"fecha_registro: \"$fecha_registro\"}";
                            
                            if($cuenta<$c_calificaciones){echo ",";}
                            $users[] = ['id' => $id_t_usuarios, 'nombre' => $nombre, 'apellido' => $ap_paterno, 'materia' => $materia, 'calificacion' => $calificacion, 'fecha_registro' => $fecha_registro];                           
                            $cuenta++;
                            $total+=$calificacion;

                    }
                    $promedio=number_format($total/$cuenta,2);
                    echo "{\"promedio\":$promedio}";
                    echo "]\n";
                }
            }

        /*$users = [
            ['id' => 1, 'name' => 'John', 'email' => 'john@example.com', 'fact' => 'Loves coding'],
            ['id' => 2, 'name' => 'Jim', 'email' => 'jim@example.com', 'fact' => 'Developed on CodeIgniter'],
            ['id' => 3, 'name' => 'Jane', 'email' => 'jane@example.com', 'fact' => 'Lives in the USA', ['hobbies' => ['guitar', 'cycling']]],
        ];*/

        

        // If the id parameter doesn't exist return all the users
/*
        if ($id === NULL)
        {
            // Check if the users data store contains users (in case the database result returns NULL)
            if ($users)
            {
                // Set the response and exit
                $this->response($users, REST_Controller::HTTP_OK); // OK (200) being the HTTP response code
            }
            else
            {
                // Set the response and exit
                $this->response([
                    'status' => FALSE,
                    'message' => 'No records were found'
                ], REST_Controller::HTTP_NOT_FOUND); // NOT_FOUND (404) being the HTTP response code
            }
        }

        // Find and return a single record for a particular user.

        $id = (int) $id;

        // Validate the id.
        if ($id <= 0)
        {
            // Invalid id, set the response and exit.
            $this->response(NULL, REST_Controller::HTTP_BAD_REQUEST); // BAD_REQUEST (400) being the HTTP response code
        }

        // Get the user from the array, using the id as key for retrieval.
        // Usually a model is to be used for this.

        $user = NULL;

        if (!empty($users))
        {
            foreach ($users as $key => $value)
            {
                if (isset($value['id']) && $value['id'] === $id)
                {
                    $user = $value;
                }
            }
        }

        if (!empty($user))
        {
            $this->set_response($user, REST_Controller::HTTP_OK); // OK (200) being the HTTP response code
        }
        else
        {
            $this->set_response([
                'status' => FALSE,
                'message' => 'User could not be found'
            ], REST_Controller::HTTP_NOT_FOUND); // NOT_FOUND (404) being the HTTP response code
        }
        */
    }
    public function calificaciones_post()
    {
        $this->load->model('pago_md');      
        $error=0;$msg="";
        $materia=$this->input->post('materia');
        $usuario=$this->input->post('usuario');
        $calificacion=$this->input->post('calificacion');
        if($materia=="")
        {
            $error=1;
            $msg.="No se ha definido la materia\n";
        }
        if($usuario=="")
        {
            $error=1;
            $msg.="No se ha definido el usuario\n";
        }
        if($calificacion=="")
        {
            $error=1;
            $msg.="No se ha definido la calificacion\n";
        }
        if($error==1)
        {
            echo "Existen algunos errores,por favor revise:\n";
            echo $msg;
            exit;
        }
        /*
        $message = [
            'id' => 100, // Automatically generated by the model
            'name' => $this->post('name'),
            'email' => $this->post('email'),
            'message' => 'Added a resource'
        ];
        */
            $data = array(                             
                            'id_t_materias' => $materia,
                            'id_t_usuarios' => $usuario,
                            'fecha_registro' => date('Y-m-d'),
                            'calificacion' => $calificacion
            );

            $resultado = $this->pago_md->agrega_calificacion($data);
            if($resultado==1)
            {
                #$message=['message' => '{"success":"ok":"msg":"calificacion registrada"}'];
                echo '{"success":"ok":"msg":"calificacion registrada"}';
            }
            else
            {
                echo  '{"error":"":"msg":"calificacion no registrada"}';
            }

            

        #$this->set_response($message, REST_Controller::HTTP_CREATED); // CREATED (201) being the HTTP response code
    }

    public function calificaciones_delete($id=0)
    {
        $this->load->model('pago_md');
        
        // Validate the id.
        if ($id <= 0)
        {
            // Set the response and exit
            echo "El id no ha sido definido";
            $this->response(NULL, REST_Controller::HTTP_BAD_REQUEST); // BAD_REQUEST (400) being the HTTP response code
        }
        else
        {
            $resultado = $this->pago_md->elimina_calificacion($id,0);
            if($resultado==1)
            {
                #$message=['message' => '{"success":"ok":"msg":"calificacion registrada"}'];
                echo '{"success":"ok":"msg":"calificacion eliminada"}';
            }
            else
            {
                echo  '{"error":"":"msg":"calificacion no eliminada"}';
            }
        }

        // $this->some_model->delete_something($id);
        $message = [
            'id' => $id,
            'message' => 'Deleted the resource'
        ];

        #$this->set_response($message, REST_Controller::HTTP_NO_CONTENT); // NO_CONTENT (204) being the HTTP response code
        #$this->set_response($message, REST_Controller::HTTP_OK); // NO_CONTENT (204) being the HTTP response code
    }

public function calificaciones_put($id=0,$materia=0,$usuario=0,$calificacion=0)
    {
        $this->load->model('pago_md');
        $error=0;$msg="";
        
        if($id=="0")
        {
            $error=1;
            $msg.="No se ha definido el id de la calificacion\n";
        }
        if($materia=="0")
        {
            $error=1;
            $msg.="No se ha definido la materia\n";
        }
        if($usuario=="0")
        {
            $error=1;
            $msg.="No se ha definido el usuario\n";
        }
        if($calificacion=="0")
        {
            $error=1;
            $msg.="No se ha definido la calificacion\n";
        }
        if($error==1)
        {
            echo "Existen algunos errores,por favor revise:\n";
            echo $msg;
            exit;
        }
        // Validate the id.
        if ($id <= 0)
        {
            // Set the response and exit
            echo "El id no ha sido definido";
            $this->response(NULL, REST_Controller::HTTP_BAD_REQUEST); // BAD_REQUEST (400) being the HTTP response code
        }
        else
        {
            $data = array(  
                            'id_t_calificaciones' => $id,                           
                            'id_t_materias' => $materia,
                            'id_t_usuarios' => $usuario,
                            'fecha_registro' => date('Y-m-d'),
                            'calificacion' => $calificacion
            );
            $resultado = $this->pago_md->actualiza_calificacion($data,0);
            if($resultado==1)
            {
                #$message=['message' => '{"success":"ok":"msg":"calificacion registrada"}'];
                echo '{"success":"ok":"msg":"calificacion actualizada"}';
            }
            else
            {
                echo  '{"error":"":"msg":"calificacion no actualizada"}';
            }
        }

        // $this->some_model->delete_something($id);
        $message = [
            'id' => $id,
            'message' => 'Deleted the resource'
        ];

        #$this->set_response($message, REST_Controller::HTTP_NO_CONTENT); // NO_CONTENT (204) being the HTTP response code
        #$this->set_response($message, REST_Controller::HTTP_OK); // NO_CONTENT (204) being the HTTP response code
    }

}
